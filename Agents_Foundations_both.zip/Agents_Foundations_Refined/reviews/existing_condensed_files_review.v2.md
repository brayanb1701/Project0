# Existing Condensed and Derived Files Review (v2)

## Framing correction

The earlier review treated too many files as if they were all attempting the same job.

They were not.

This corpus actually contains at least three different artifact types:

1. **Source-local condensations**  
   Goal: compress one source while preserving detail.

2. **Synthetic principle docs**  
   Goal: express the preferred invariant layer for the system.

3. **Style / methodology experiments**  
   Goal: explore different ways of preserving and restructuring knowledge.

Any review that ignores those different goals will misjudge some of the files.

---

## Updated verdicts

| File | Better interpretation | Updated verdict |
|---|---|---|
| `Prompt Caching is Everything.condensed*` | Strong source-local condensation | Keep |
| `Skills_Use_Anthropic_engineer.condensed*` | Strong detailed condensation / wiki input | Keep and extend |
| `Harness_Engineering.condensed*` | Good source-local condensation, but not final invariant layer | Merge |
| `Architecture_Doc_Principles*` | Strong refined principle file | Keep as high-weight synthesis |
| `Agent_Oriented_Thinking*` | Synthetic invariant layer, not a source-local summary | Keep as high-weight synthesis |
| `Agent_Project_Principles*` | Synthetic invariant layer, not a source-local summary | Keep as high-weight synthesis |

---

## Most important correction

`knowledge_extraction_prompt.md` and the later skill-like iterations were not aiming at exactly the same output.

### `knowledge_extraction_prompt.md`
Primary goal:
- extract principles / invariants
- produce the most condensed source of truth possible
- optimize for system guidance

### Later condensation-oriented iterations
Primary goal:
- preserve more detail
- create material that could feed a wiki / vault / knowledge base
- remain highly compressed, but not necessarily minimal at the invariant layer

Those are adjacent goals, but not identical.  
Future evaluations should judge artifacts against the goal they were actually trying to serve.

---

## What this changes for the corpus

### Files to treat as preferred synthesis
These should have more weight in future runs:
- `Agent_Project_Principles*`
- `Agent_Oriented_Thinking*`
- `Architecture_Doc_Principles*`

### Files to treat as detailed feedstock
These remain valuable as richer support layers:
- `Prompt Caching is Everything.condensed*`
- `Skills_Use_Anthropic_engineer.condensed*`
- `Harness_Engineering.condensed*`

### Files to treat carefully
Useful, but lighter-weight or more exploratory:
- `AI-Engineer-Conference-EU-0426*`
- `Dex Process on coding with agents*`

---

## Recommended evaluation rule for future runs

For each file, first ask:

- Was this trying to be a **canonical invariant file**?
- a **source-faithful condensation**?
- a **workflow experiment / style experiment**?

Only then decide whether to keep, merge, or replace it.
