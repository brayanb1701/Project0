# Methodology Assessment and Structure (v2)

## Main correction

The earlier assessment leaned too much toward **condensation quality**.  
The corrected framing is:

- the target is **working invariants**
- traceability is **best-effort provenance**
- some files are already **author-refined preferred formulations**
- stable architecture principles should be separated from evolving workflows

## What this means in practice

### 1. “Invariant” should mean “currently durable and system-useful”
Not “timeless truth.”  
If a principle is useful but likely to mutate, keep it in an evolving heuristic layer.

### 2. Traceability should be honest
Preserve provenance aggressively, but do not overclaim precision.  
The right promise is “auditable enough to refine,” not “formally complete.”

### 3. Source weighting matters
Some files should be treated as stronger synthesis inputs:
- `Agent_Project_Principles*`
- `Agent_Oriented_Thinking*`
- `Architecture_Doc_Principles*`

Those are not just artifacts to critique; they are part of the intended direction of the corpus.

### 4. The final structure should separate:
- durable foundations / architecture
- evolving workflow playbooks
- provider / harness-specific tactics
- evidence and provenance

### 5. Missing concept now made explicit
The prior structure under-emphasized:
- modularity
- stable core / volatile edge design
- autonomy / supervision modes
- throughput as a signal rather than the objective

## Recommended structure now

- foundations
- architecture / legibility / modularity
- workflow / research / planning / review
- harness / context / verification
- skills
- prompt caching
- autonomy / supervision / release modes
- provenance / traceability
