# Repository Architecture, Legibility, and Control (v2)
> Revised from the earlier extraction using corpus evidence plus operator feedback.
> Focus: durable architecture principles, not only process preferences.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Knowledge Architecture

`[RA-01]` `P` **Treat the repository as the system of record.** For agents, durable knowledge should live in versioned repo artifacts: architecture docs, specs, execution plans, generated schemas, and reference material.

`[RA-02]` `P` **Top-level agent docs should be maps, not encyclopedias.** AGENTS.md or CLAUDE.md should orient and point onward, not attempt to inline the whole knowledge base.

`[RA-03]` `P` **Plans are first-class repository artifacts.** Long-horizon work needs durable plans, decision logs, and debt records that survive session boundaries.

`[RA-04]` `P` **Validate documentation freshness mechanically.** Use linters, CI, and recurring maintenance agents to keep the repo’s knowledge layer aligned with the code.

---

## Modularity and Layered Design

`[RA-05]` `P` **Design projects as modular systems with explicit boundaries.** Agents perform best when they can work within one area without corrupting unrelated areas.

`[RA-06]` `P` **Prefer a small stable core with more volatile layers on top.** Keep the deepest logic simple, legible, and heavily constrained; push integrations, UI variation, workflow orchestration, and other fast-changing complexity outward.

`[RA-06.A]` `A` **Operational implication.** When new complexity appears, first ask whether it belongs in the outer layers rather than the core.

`[RA-07]` `P` **Make dependency direction and placement rules unambiguous.** The agent should know exactly where new code goes, what can depend on what, and where cross-cutting concerns are injected.

> `[RA-07.E1]` `E` OpenAI’s example layer model is Types → Config → Repo → Service → Runtime → UI, with cross-cutting concerns entering through an explicit Providers interface.

`[RA-08]` `P` **Use known patterns worth matching.** Agents pattern-match on what already exists, so repeated structure, naming conventions, and consistent module shapes are architectural tools, not cosmetic choices.

---

## Application Legibility

`[RA-09]` `P` **Optimize the codebase for agent legibility.** The repository should be easy for future agent runs to inspect, reason about, and modify.

`[RA-10]` `P` **Make the running system observable to agents, not just the source tree.** Agents need to reproduce failures, validate fixes, and reason about actual behavior through the app, logs, metrics, traces, or equivalent runtime signals.

`[RA-11]` `P` **Isolate each task’s environment.** A change should run against its own app instance and its own observability context so validation results remain attributable to the current work.

`[RA-12]` `P` **Prefer boring, inspectable, composable technology.** Stable APIs and inspectable abstractions are easier for agents to reason about than opaque wrappers or magical dependencies.

> `[RA-12.E1]` `E` OpenAI describes implementing an internal concurrency helper instead of relying on a small opaque dependency so the behavior stayed inspectable and tightly integrated with telemetry.

---

## Enforcement and Entropy

`[RA-13]` `P` **Enforce invariants, not implementations.** Define strict structural boundaries and allowed edges, then allow freedom inside them.

`[RA-14]` `P` **Encode taste as checks, not recurring comments.** When a review note repeats, promote it into a linter, structural test, or template.

`[RA-15]` `P` **Design away hidden magic and local patch-fixes.** Local fixes that silently swallow failure or hide system behavior may look correct in one file while making the whole system harder to trust.

`[RA-16]` `P` **Manage entropy continuously.** Background cleanup, targeted refactors, and pre-submission normalization are necessary because agents amplify whatever patterns already exist.

---

## Control, Throughput, and Autonomy

`[RA-17]` `P` **Throughput is a health signal, not the goal.** Measure speed and volume because they reveal capability, but optimize for a codebase that remains understandable, governable, and evolvable by both the operator and the system.

`[RA-17.A]` `A` **Operational implication.** A fast system that steadily destroys controllability is failing, even if PR counts look impressive.

> `[RA-17.E1]` `E` The corpus includes high-throughput examples from both OpenAI and ace-fca, but the durable lesson is not “maximize output”; it is “make speed safe through structure, validation, and review.”

`[RA-18]` `P` **Operator control should tighten as criticality rises.** Production and cross-cutting work need stronger boundaries, observability, and review than prototypes, MVP demos, or exploratory branches.

`[RA-19]` `P` **Relaxed modes should be explicit, not accidental.** When you intentionally loosen rules for prototypes or early idea exploration, make that mode visible so its outputs are not mistaken for production-grade patterns.

`[RA-20]` `P` **Autonomy should grow only on top of maintainability.** The system earns more freedom when the repo stays legible, the feedback loops stay strong, and the human can still recover global understanding when needed.

---

## Anti-Patterns

- Leaving modularity implicit and hoping the agent infers boundaries.
- Letting fast-moving edge concerns leak into the stable core.
- Treating throughput as success even while maintainability declines.
- Allowing prototype-grade shortcuts to become default production patterns by accident.
- Depending on opaque behavior when a small inspectable abstraction would be safer.
