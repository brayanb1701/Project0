# Workflow, Research, Planning, and Review (v2)
> Revised from the earlier extraction using corpus evidence plus operator feedback.
> Status: **evolving operating playbook**, not a final invariant set.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Stable Guidance

`[WF-01]` `P` **Humans steer; agents execute.** Human leverage is highest in framing the problem, choosing the level of supervision, reviewing the highest-leverage artifacts, and deciding where judgment is still required.

`[WF-02]` `P` **Do not outsource the thinking.** The agent can accelerate exploration and implementation, but humans remain responsible for task framing, acceptance criteria, and deciding what “good” means.

`[WF-03]` `P` **Review the highest-leverage artifact, not only the final code.** Research errors and planning errors have a larger blast radius than implementation mistakes, so review time should concentrate there first.

`[WF-04]` `P` **Use durable state, not chat transcripts, as the operating memory.** Plans, research notes, and progress summaries should carry the truth of the task between sessions.

`[WF-05]` `P` **Good agent tasks are scoped, closed-loop, and easy to evaluate.** Prefer work the agent can verify, where the blast radius is bounded and success criteria are concrete.

`[WF-06]` `P` **Risk should determine review depth.** Critical, cross-cutting, or hard-to-reverse changes deserve more scrutiny than prototypes, reproduction cases, or exploratory branches.

`[WF-06.A]` `A` **Operational implication.** Review policy should be tied to risk, not applied uniformly across all work.

---

## Strong Starting Defaults, Not Final Law

`[WF-07]` `P` **Research → plan → implement is a strong default shape for complex work.** Keep the phases distinct enough that each can be reviewed and compacted independently, but treat the shape as an operating default rather than a permanent law.

> `[WF-07.E1]` `E` ace-fca reports that research-backed plans produced better placement and better verification choices than no-research plans in a large unfamiliar codebase.

`[WF-08]` `P` **Research should compress truth before it suggests action.** Define the right questions, gather evidence, and keep premature implementation bias out of the research layer.

`[WF-09]` `P` **Planning should be modular and vertically executable.** Break work into design, structure, and implementation phases that an agent can actually follow, rather than wide horizontal wish lists.

> `[WF-09.E1]` `E` Dex notes that planning should be modular, that structure can precede the full plan, and that vertical plans work better than broad horizontal ones.

`[WF-10]` `P` **Compact before the context becomes garbage.** File searches, logs, tool chatter, and exploratory reads should be distilled into a compact progress artifact before they crowd out the task.

> `[WF-10.E1]` `E` Both ace-fca and Pi describe writing distilled markdown artifacts so the main session only keeps the verified signal.

`[WF-11]` `P` **Update the plan as the task state changes.** Verified progress should be written back into the durable artifact so the next session resumes from truth rather than from stale narrative.

---

## Workflow Evolution

`[WF-12]` `P` **Treat workflow as a testable operating policy.** Keep the current workflow file because it is useful, but assume it will evolve as better patterns emerge.

`[WF-12.A]` `A` **Operational implication.** Workflow docs should be versioned and revised from usage, not treated as scripture.

`[WF-13]` `P` **Compare workflow variants empirically.** When possible, test the same class of work under different supervision levels, review intensities, or decomposition strategies and compare manageability, correctness, and follow-up cost.

`[WF-14]` `P` **Precision mode and exploratory mode are both valid, but they serve different purposes.** Exact engineering work needs tighter steering; prototype or discovery work can tolerate looser specification and faster iteration.

`[WF-15]` `P` **There is no magic prompt.** Better workflow increases success rates, but hard problems still require steering, iteration, and sometimes genuine codebase expertise.

> `[WF-15.E1]` `E` ace-fca reports both impressive brownfield wins and notable failures on harder dependency-heavy work, reinforcing that workflow improves odds but does not replace judgment.

---

## Anti-Patterns

- Treating a workflow playbook as an eternal invariant.
- Letting chat history become the real source of task state.
- Reviewing only code while skipping research and plans.
- Applying the same review rigor to every task regardless of risk.
- Expecting one prompt to replace engaged steering and task decomposition.
