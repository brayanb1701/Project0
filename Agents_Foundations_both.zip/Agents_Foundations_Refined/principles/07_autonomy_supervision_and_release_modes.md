# Autonomy, Supervision, and Release Modes
> New document added from corpus synthesis plus operator feedback.
> Purpose: make autonomy a governed variable instead of an implicit drift.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Core Principle

`[AS-01]` `P` **Autonomy should be graduated, not binary.** The right amount of agent freedom depends on task criticality, reversibility, observability, and the maturity of the repo’s guardrails.

`[AS-02]` `P` **Supervision level is a design choice and an experimental variable.** Compare how the same class of work behaves under different review and autonomy settings instead of treating one policy as universally correct.

`[AS-03]` `P` **The goal is not maximal independence; it is reliable leverage.** More autonomy is only good when the codebase remains manageable and the operator retains control.

---

## Suggested Modes

`[AS-04]` `P` **Prototype / exploration mode can be permissive.** For idea validation, internal demos, reproduction cases, or throwaway experiments, accept looser rules and faster iteration.

`[AS-05]` `P` **Standard development mode should be structured.** Use stable plans, bounded tasks, validation, and lightweight review appropriate to the risk.

`[AS-06]` `P` **Production / critical-path mode should be constrained.** Cross-cutting, security-sensitive, reliability-sensitive, or hard-to-reverse work should have stronger observability, clearer boundaries, and deeper review.

`[AS-07]` `P` **Mode transitions need explicit criteria.** Do not let work drift from prototype assumptions into production expectations without changing the guardrails.

---

## Governance Rules

`[AS-08]` `P` **Tighten review as blast radius rises.** Review depth should scale with criticality, not with ideology about speed or human pride in reading every line.

`[AS-09]` `P` **Only loosen rules intentionally.** If a repo or branch is operating under relaxed constraints, that state should be named so the resulting patterns do not silently become the standard.

`[AS-10]` `P` **Autonomy is earned through feedback loops.** Better tests, runtime observability, linting, and repair paths justify more freedom; weak feedback loops require more supervision.

`[AS-10.A]` `A` **Operational implication.** Autonomy should increase when the system can detect and localize its own mistakes, not merely when the model appears faster.

---

## What to Measure

`[AS-11]` `P` **Measure manageability, not just output.** Track throughput, but also track review burden, rework, defect escape, architectural drift, and how hard it is for the operator to regain understanding.

`[AS-12]` `P` **Use supervision experiments to guide policy.** Re-run similar work under different autonomy levels and compare not only speed, but the downstream cleanup and control costs.

---

## Anti-Patterns

- Treating autonomy as something to maximize in the abstract.
- Using the same supervision policy for prototypes and critical production paths.
- Letting prototype shortcuts silently become production norms.
- Measuring only throughput while ignoring review burden, drift, and rework.
- Increasing freedom without improving verification and observability first.
