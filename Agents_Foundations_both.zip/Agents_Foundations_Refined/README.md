# Agents Foundations Refined Pack

This pack updates the previous extraction based on new guidance:

- the target is **working invariants**, not a generic knowledge vault
- traceability is treated as **best-effort provenance**, not formal proof
- source files have **different weights**
- workflow guidance is separated from more durable architecture principles
- throughput is treated as a **signal**, not the goal
- modularity, layered design, and **stable core / volatile edge** design are made explicit
- autonomy is treated as **graduated and risk-dependent**

## Files

- `prompts/corpus_extraction_request_v2.md` — rewritten version of the original task prompt
- `prompts/knowledge_extraction_prompt_v2.md` — improved extraction methodology prompt
- `methodology_and_corpus_rules.md` — source weighting, conflict handling, and traceability rules
- `principles/02_workflow_research_planning_and_review.v2.md` — revised workflow guidance
- `principles/04_repository_architecture_and_legibility.v2.md` — revised architecture guidance
- `principles/07_autonomy_supervision_and_release_modes.md` — new autonomy / supervision policy layer

- `methodology_assessment_and_structure.v2.md` — shorter direct replacement for the earlier methodology note
- `reviews/existing_condensed_files_review.v2.md` — revised review with artifact-type awareness
