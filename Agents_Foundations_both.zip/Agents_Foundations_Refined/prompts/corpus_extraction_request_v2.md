# Corpus Extraction Request v2 — Working Invariants for Agent-Built Software

You are given a corpus of articles, notes, refined principle files, condensed files, and methodology prompts about building software with and for LLM coding agents.

Your job is **not** to produce a general-purpose summary, wiki, or vault.  
Your job is to extract the smallest durable set of **working invariants** that should guide our system **today**, while also preserving the supporting heuristics, evidence, and source tensions that matter for future refinement.

These invariants are **versioned working rules**, not eternal truths. Keep what seems durable and broadly useful now, but explicitly separate anything that is more likely to change as models, harnesses, or our internal practices evolve.

---

## Goal

Produce a domain-organized corpus that future agents and humans can actually use as a source of truth for building and evolving agent-first software systems.

The output should optimize for:

1. **Usefulness for the system**
2. **Preservation of distinct ideas**
3. **Clear separation between durable invariants and evolving workflows**
4. **Mechanical applicability**
5. **Best-effort provenance**

---

## Source Types and Weight

Treat sources differently instead of flattening them into one authority level.

### Highest weight — author-refined synthetic principle docs
These may already encode intentional judgments and preferred formulations:
- `Agent_Project_Principles*`
- `Agent_Oriented_Thinking*`
- `Architecture_Doc_Principles*`

Use these as **high-signal refined priors**, not just as artifacts to critique.

### High weight — primary articles / substantial essays
Examples:
- `Harness_Engineering*`
- `Prompt Caching is Everything*`
- `Skills_Use_Anthropic_engineer*`
- `ace-fca*`
- `Manage_Context_Window_DanielGriesser*`

### Medium / lower weight — notes, captures, incomplete or exploratory material
Examples:
- `AI-Engineer-Conference-EU-0426*`
- `Dex Process on coding with agents*`

These are still useful, but they should not override stronger sources unless they add a missing concept or sharper wording.

### Special case — existing condensed files
Existing `.condensed.md` files are:
- examples of style
- partial prior syntheses
- comparison targets

They are **not authoritative by default** over higher-weight sources.

---

## What to Extract

Process **every file**. Extract every distinct:

- principle
- rule
- constraint
- fact
- example
- anti-pattern
- tension / conflict
- explicit caveat
- mechanical enforcement point
- placement rule
- rationale

Condensing means fewer words, **not fewer ideas**.

---

## Required Distinctions

When synthesizing, explicitly separate:

### 1. Canonical Working Invariants
These are the smallest durable principles we want the system to rely on now.

### 2. Evolving Heuristics / Workflow Rules
Useful, but likely to change with model capability, harness design, or experimentation.

### 3. Evidence / Case-Study Facts / Examples
Concrete source-specific evidence, metrics, anecdotes, or implementations.

### 4. Tensions / Conflicts
Do not silently merge conflicts into mush. Surface them and resolve them using source weight plus reasoning. If unresolved, say so explicitly.

---

## Extra Requirements

### A. Preserve P / E / A
Use:
- `P` = principle
- `E` = implementation example / fact / evidence
- `A` = agent-specific consideration

But also make clear whether a principle is:
- a **working invariant**
- an **evolving heuristic**

### B. Best-effort provenance, not fake certainty
Produce a traceability file, but treat it as **best-effort provenance**, not formal proof that every idea is perfectly mapped.

### C. Conflict resolution must be explicit
When sources differ:
1. prefer higher-weight sources
2. prefer more explicit and mechanically enforceable guidance
3. prefer formulations that preserve operator control and long-term manageability
4. preserve the losing view as a noted tension when still useful

### D. Do not collapse architecture into workflow
Keep stable architecture / legibility / modularity principles separate from mutable process preferences.

### E. Capture modularity and layered scaling explicitly
Make sure the final principles explicitly cover:
- modular design
- clear boundaries
- a stable core with volatile layers on top
- complexity pushed outward rather than inward
- explicit placement rules for new code

### F. Throughput is a signal, not the north star
Track throughput, but optimize for a codebase that remains controllable by the human operator and by the system itself over time.

### G. Autonomy should be graduated
Include principles about:
- supervision levels
- when stricter review is required
- when looser rules are acceptable (e.g. prototypes / MVPs / exploration)
- when production / critical paths require stronger constraints

### H. Reuse good existing principle files
If some already-refined files are strong, revise or merge them instead of discarding them just because they are synthetic.

---

## Deliverables

### 1. Domain-organized principle files
Group by domain / purpose, not by source.

A likely structure is:
- foundations
- architecture / legibility / modularity
- workflow / research / planning / review
- harness / context / verification
- skills
- prompt caching
- autonomy / supervision / release modes

Use the corpus to decide the final split.

### 2. Traceability file
For each extracted principle / rule / fact:
- source file
- source anchor or section
- destination output file
- notes if merged, downgraded to heuristic, or marked conflicting

Again: **best-effort provenance**, not fake precision.

### 3. Existing condensed files review
Evaluate the existing condensed / derived files with awareness that:
- some are style exemplars
- some are intentionally refined principle docs
- not all were trying to do the same job

### 4. Methodology / structure note
Explain:
- how you interpreted “working invariants”
- how you handled source precedence
- how you handled traceability limitations
- why you chose the final file structure

---

## Response Text Must Also Include

- thin / redundant / contradictory sources
- cross-cutting themes that appear in 3+ files
- conflicts and how you resolved them
- keep / replace / merge assessment for existing condensed / derived files
- any principles that seemed missing from the original packet but should likely be added to future versions

---

## Output Style

- concise
- high-signal
- domain-organized
- no silent idea loss
- optimized for future system use, not for literary completeness
