# Knowledge Extraction & Working-Invariant Distillation Prompt v2

## Prompt

You are given one document or a small set of related documents.

Your task is to extract **all meaningful knowledge** from them, then distill that knowledge into a form that is maximally useful for future LLM-agent operation.

This is **not** just summarization.  
It is a three-part process:

1. **Extract everything distinct**
2. **Distill into working invariants vs evolving heuristics**
3. **Augment for agent operation**

Working invariants are **current durable rules**, not timeless truths.  
If a claim seems useful but likely to change with model capability, tooling, or workflow evolution, keep it — but classify it as an evolving heuristic instead of smuggling it into the invariant layer.

---

## Phase 0 — Source Framing

Before extracting, identify:

- source type: `primary` / `derived` / `note-like`
- likely authority: `high` / `medium` / `low`
- likely volatility of claims: `stable` / `mixed` / `volatile`

Do not hide this judgment. It affects how aggressively you promote claims into the invariant layer.

---

## Phase 1 — Extract Everything Distinct

Follow these rules strictly:

### 1. Separate principles from evidence
Every extracted item must be one of:
- `P` — Principle, rule, belief, invariant, or heuristic
- `E` — Evidence, example, fact, implementation detail, metric, case study, or anecdote
- `A` — Agent-specific consequence or modification

### 2. Preserve all distinct ideas
Condensing means fewer words, not fewer ideas.  
If something appears once and is useful, capture it.  
If it is redundant, merge it explicitly into a broader principle instead of silently dropping it.

### 3. Keep facts factual
If the source gives case-study numbers, dates, constraints, caveats, or scope limits, preserve them as `E` items.

### 4. Extract tensions, not just rules
If the source contains tradeoffs, scope limits, or caveats, capture them explicitly.  
Do not flatten “it depends” into a falsely universal principle.

### 5. Group by theme, not source order
Surface the underlying conceptual structure, not the order of the source text.

---

## Phase 2 — Distill Into Two Layers

### Layer 1 — Working Invariants
Promote a `P` item into the invariant layer only if it is:
- broadly reusable
- likely to remain useful across projects
- stated strongly enough or repeated enough to deserve canonical status

### Layer 2 — Evolving Heuristics
Keep a `P` item in the heuristic layer if it is:
- workflow-specific
- likely to mutate
- dependent on current model behavior
- not yet robust enough to be treated as canonical

Do **not** discard heuristic material just because it is not canonical.

---

## Phase 3 — Augment for LLM Agents

For each principle, ask:

- Does this change when the actor is an agent, not a human?
- Is there a silent failure mode for agents?
- Does the agent need an explicit placement rule or injection point?
- Can this be tied to mechanical enforcement?
- Should the agent update or maintain this knowledge as part of its workflow?

If yes, add an `A` item.

Use these ideas to guide augmentation:

- agents start cold every run
- context is finite
- repo-local discoverability matters
- staleness silently corrupts agent reasoning
- explicit beats implicit
- unexplained constraints get optimized away
- agents replicate existing patterns including bad ones
- mechanical enforcement beats prose

---

## Traceability Rule

Maintain **best-effort provenance** while extracting:

- source file
- source section or heading
- where the claim ended up
- whether it was promoted to invariant, kept as heuristic, or preserved as evidence

Do not pretend this is formal proof. It is a practical audit trail.

---

## Output Format

Use this structure:

```md
# [Topic] Principles
> Source: [document name or description]
> Source type: [primary / derived / note-like]
> Stability focus: [working invariants / mixed / evolving]
> Augmented for LLM agent contexts

**Legend:** `P` = Principle · `E` = Evidence / Example · `A` = Agent-specific consideration

---

## Working Invariants

`P` **[Principle title].** [One or two sentence explanation.]

`A` **[Agent consideration].** [Why this matters specifically for agents.]

> `E` [Specific evidence, example, or metric.]

---

## Evolving Heuristics

`P` **[Heuristic title].** [Keep concise but preserve the idea.]

`A` **[Agent consideration].** [...]

> `E` [Specific evidence, example, or metric.]

---

## Tensions / Scope Limits

- [Conflict, tradeoff, or caveat]
- [How it should be interpreted]

---

## Anti-Patterns

- [Thing to avoid]
- [Thing to avoid]
```

---

## Additional Guidance

- Be maximally concise, but never at the cost of silent idea loss.
- Prefer the strongest formulation that the source actually supports.
- Preserve rationale, not just instruction.
- Prefer stable maps over encyclopedic restatement.
- If a document is already a refined principle file, evaluate whether to preserve its wording rather than rephrasing it unnecessarily.

---

## Input

Apply this to the following:

[PASTE TEXT OR FILE CONTENT HERE]
