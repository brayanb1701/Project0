# Methodology and Corpus Rules v2

## 1. What changed conceptually

The earlier pass was still partially optimized for **high-fidelity condensation**.  
This revision is optimized for **working invariants for a live system**.

That changes the method in four important ways:

1. **Not every preserved idea belongs in the canonical layer.**  
   We now explicitly separate:
   - working invariants
   - evolving heuristics
   - evidence / examples
   - tensions

2. **Source files do not all carry equal weight.**  
   Some files are already refined by the author and should be treated as intentional preferred formulations, not merely as raw material.

3. **Traceability is practical provenance, not proof.**  
   The goal is “good enough to audit and refine,” not fake certainty.

4. **Architecture and controllability outrank raw throughput.**  
   We track speed, but we optimize for a codebase that remains legible and governable by both the operator and the system.

---

## 2. Definition of “working invariant”

A working invariant is:

- durable enough to be worth encoding now
- useful across multiple projects or repos
- specific enough to change behavior
- strong enough to survive compression
- likely to remain useful even as tactics evolve

It is **not** assumed to be timeless.  
If a principle is useful but likely to mutate with model capability or workflow experimentation, it belongs in the heuristic layer.

---

## 3. Source weighting

### Highest-weight refined synthesis
Use as preferred formulations unless contradicted by stronger primary evidence:

- `Agent_Project_Principles*`
- `Agent_Oriented_Thinking*`
- `Architecture_Doc_Principles*`

Reason: these appear to encode prior deliberate refinement rather than raw extraction.

### High-weight primary material
Use as principal evidence and scope anchors:

- `Harness_Engineering*`
- `Prompt Caching is Everything*`
- `Skills_Use_Anthropic_engineer*`
- `ace-fca*`
- `Manage_Context_Window_DanielGriesser*`

### Medium / lower-weight note material
Use to sharpen or extend the corpus, but do not let it dominate conflicts:

- `AI-Engineer-Conference-EU-0426*`
- `Dex Process on coding with agents*`

### Existing condensed files
Treat as:
- style exemplars
- partial prior synthesis
- comparison targets

Do not automatically let them override stronger sources.

---

## 4. Conflict handling

When two sources differ:

1. prefer the higher-weight source
2. prefer the formulation with clearer scope and rationale
3. prefer the formulation that is more mechanically enforceable
4. prefer the one that preserves maintainability and operator control
5. keep the losing view as a tension if it remains useful

Examples of tensions that should remain visible:

- environment fixes first vs model escalation
- speed vs review depth
- long context vs context isolation
- autonomy vs operator control

---

## 5. Traceability policy

Traceability should now be described as **best-effort provenance**.

That means:

- every important output item should point back to source material
- source anchors should be specific enough to re-find the idea
- merged items should note that they were merged
- unresolved ambiguity should be admitted

It does **not** mean:

- pretending every sentence can be perfectly reconstructed from one unique source
- claiming full formal coverage
- hiding judgment calls behind false precision

For this corpus, that level of honesty is more useful than brittle pseudo-exactness.

---

## 6. Structural decisions for the principle set

The principle set should now distinguish more clearly between:

### A. Durable foundations / architecture
These should change slowly:
- repo as system of record
- explicitness
- mechanical enforcement
- modularity
- layered design
- stable core / volatile edge
- agent legibility
- continuous entropy management

### B. Evolving operating playbooks
These are strong starting defaults, not fixed law:
- research / plan / implement
- compaction cadence
- plan granularity
- subagent patterns
- review workflow details
- release / supervision modes

### C. Runtime-specific tactics
These may be provider or harness specific:
- prompt caching rules
- tool search / deferred loading
- model handoff patterns
- specific skill packaging conventions

---

## 7. Important additions that should now be explicit

### Modularity and layered complexity
Projects should be designed as modular systems with a small, stable core and layers around it.  
Complexity should be pushed outward.  
Agents need both explicit boundaries and explicit placement rules.

### Operator control over throughput
Throughput should be measured, but not treated as the goal.  
The real target is sustained controllability:
- can the operator still understand and govern the codebase?
- can the system still reason over it reliably?
- can autonomy be increased without hidden debt exploding?

### Graduated autonomy
Different project phases should tolerate different levels of looseness:
- prototype / showroom / exploratory work
- MVP / early productization
- production feature work
- critical or high-risk paths

The corpus should encode that autonomy and review are **risk-tiered**, not one-size-fits-all.

---

## 8. Practical guidance for future runs

For future extraction passes, ask for three outputs explicitly:

1. **Canonical invariant layer**
2. **Evolving heuristic / playbook layer**
3. **Evidence + provenance layer**

That single change will likely improve usefulness more than any stylistic improvement.
