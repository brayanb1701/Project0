# Review of Existing Condensed and Derived Files

## Verdict summary

| File | Verdict | Assessment |
|---|---|---|
| `Harness_Engineering.condensed(2).md` | **Merge / replace in final corpus** | Strong source-local condensation, but too source-bound for the final structure and missing several scope caveats. |
| `Prompt Caching is Everything.condensed(2).md` | **Keep with minor edits** | High-fidelity and nearly complete; only a few provider-scope and implementation details are omitted. |
| `Skills_Use_Anthropic_engineer.condensed(2).md` | **Keep, then extend / merge** | Strong structure and clear theme grouping, but it drops some operational details around verification, composition, measurement, and curation. |
| `Agent_Project_Principles(2).md` | **Merge, not keep as canonical extraction** | Useful synthesis, but it is more interpretive than source-faithful and introduces extrapolations not clearly present in the source. |
| `Architecture_Doc_Principles(2).md` | **Keep** | Faithful, compact, and highly usable. This is one of the strongest files in the set. |
| `Agent_Oriented_Thinking(2).md` | **Keep as synthetic foundation, not as a source-local condensation** | Useful abstract principles file, but it is already a synthesis rather than a traceable condensation of one source. |

## Detailed notes

### `Harness_Engineering.condensed(2).md`

**What it does well**
- Preserves the main thesis well: repo-as-system-of-record, agent legibility, architectural enforcement, entropy management, and autonomy through feedback loops.
- Keeps the distinction between principles and implementation examples clear.
- Organizes the content cleanly by theme.

**What it misses or over-compresses**
- It drops some of the source’s strongest **scope qualifiers**:
  - the “0 human-written code” constraint as a deliberate forcing function,
  - the fact that humans interact almost entirely through prompts,
  - the warning that the described autonomy depends heavily on repo structure and is not automatically generalizable.
- It underplays some important **operational details**:
  - agents use standard tools directly (`gh`, local scripts, repo-embedded skills),
  - observability is ephemeral per worktree,
  - the repo kept pulling more and more context in over time as new invisible knowledge was discovered.
- It does not fully preserve some useful **evidence**:
  - the million-line / 1,500-PR / 3.5-PRs-per-engineer-per-day case-study numbers are present only partially or indirectly.
- It is still **source-shaped**. For the final corpus, the OpenAI material belongs split across foundations, repo architecture, workflow, and harness files.

**Bottom line**  
Good enough as a source-local summary. Not good enough as the final corpus artifact.

### `Prompt Caching is Everything.condensed(2).md`

**What it does well**
- Very faithful to the source.
- Preserves the central constraint: prompt caching is prefix-based.
- Keeps the most important anti-patterns.
- Correctly separates prompt layout, mid-session stability, tool stability, and cache-safe compaction.

**What it misses or softens**
- It lightly compresses some useful implementation flavor:
  - the plan-mode bonus that the model can autonomously enter the mode,
  - the suggestion to use the provider’s built-in compaction feature rather than reimplementing it,
  - the concrete ordering example (`system/tools → project context → session context → conversation`).
- Provider scope is present but could be even more explicit because these patterns are Anthropic-specific in mechanism.

**Bottom line**  
This one is good. I would keep it, but I still folded it into the domain-based final structure.

### `Skills_Use_Anthropic_engineer.condensed(2).md`

**What it does well**
- Strong taxonomy.
- Strong emphasis on high-signal authoring and progressive disclosure.
- Correctly preserves the “skills are folders, not markdown” point.
- Preserves the most important trigger/setup/state/distribution concepts.

**What it misses**
- Some valuable operational specifics from the source:
  - verification skills being worth deep investment,
  - recording videos and asserting state in verification flows,
  - composition between skills,
  - measuring skill usage and undertriggering,
  - the need to curate bad or redundant skills before release.
- The file is excellent on authoring patterns, but slightly thinner on **operating and governing** a skill ecosystem.

**Bottom line**  
Strong base. Needs extension, not replacement.

### `Agent_Project_Principles(2).md`

**What it does well**
- Pulls the OpenAI article into a very usable principles document.
- Adds useful practical framing around quality floors, review rigor, and hybrid enforcement.

**Why it should not be treated as the canonical condensation**
- It introduces several interpretive additions that are not clearly in the source text:
  - explicit model escalation as a complementary strategy,
  - hybrid deterministic + LLM advisory linting as a norm,
  - configurable review rigor as a first-class policy dimension,
  - some stronger quality-floor language than the source itself uses.
- Those additions are often reasonable, but they blur the line between **extraction** and **design interpretation**.

**Bottom line**  
Useful derived memo. Better merged into the corpus than treated as the faithful source summary.

### `Architecture_Doc_Principles(2).md`

**What it does well**
- Very high fidelity and excellent concision.
- Preserves exactly the right details for agent use: maps, codemaps, invariants, boundaries, cross-cutting concerns, and agent-owned maintenance.
- Adds helpful agent-specific augmentation without drifting too far from the source.

**What I would change**
- Very little. I would mostly keep it as-is, while still merging its contents into the domain-based structure.

**Bottom line**  
One of the best files in the set.

### `Agent_Oriented_Thinking(2).md`

**What it does well**
- Excellent synthetic summary of the corpus’s recurring assumptions.
- Especially useful as a foundational file for teams that need a compact mindset document.

**Limit**
- It is already a synthesis, so it cannot stand in for traceable extraction from the whole corpus.

**Bottom line**  
Keep it as a foundation layer, but not as proof of full coverage.

## Overall judgment

The existing condensed files are **good examples of style**, especially:
- strong concision,
- clean theme grouping,
- useful anti-pattern sections,
- effective P/E/A-style thinking.

Their main weakness is **coverage drift at the edges**:
- missing caveats,
- missing operational details,
- missing metrics/evidence,
- occasional interpretive additions not clearly separated from source-faithful extraction.

That is why the final deliverable here uses:
1. domain-based files rather than source-local files,
2. stable IDs,
3. a separate review file,
4. a separate traceability map.
