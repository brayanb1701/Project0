# Methodology Assessment and Structure Rationale

## Assessment of `knowledge_extraction_prompt.md`

The prompt is a strong starting point for **single-document condensation**.

### What it gets right

- It clearly separates **principles (`P`)** from **implementation examples (`E`)**.
- It insists on **concision without idea loss**.
- It explicitly says to **group by theme, not by source order**.
- It forces an **anti-patterns section**, which is valuable because many operational lessons are best remembered as failure modes.
- Its Phase 2 augmentation questions are exactly the right ones for agent-facing material: cold starts, silent staleness, mechanical enforcement, explicit placement, and agent-maintained documentation.

### Where it is underspecified for this corpus

For a multi-document synthesis task like this one, the prompt needs a few additions:

1. **Traceability is not optional.**  
   The original prompt says not to drop ideas, but it does not require a mapping that proves coverage.

2. **Facts and case-study evidence need explicit handling.**  
   `P` and `E` are enough, but only if source-specific metrics, examples, and caveats are intentionally preserved as `E` items rather than disappearing during thematic merging.

3. **Multi-source synthesis needs source typing.**  
   This corpus mixes:
   - primary source articles,
   - already-condensed source-local summaries,
   - note-like conference captures,
   - synthetic principle docs.  
   A good method should distinguish **primary**, **derived**, and **note-like** sources.

4. **Conflict handling should be explicit.**  
   Some items are tensions rather than contradictions: speed vs. review depth, environment fixes vs. model escalation, long context vs. context isolation. A corpus-level method should require these to be surfaced and resolved.

5. **Stable IDs help both traceability and maintenance.**  
   The original format is readable, but adding IDs makes it much easier to verify coverage and update the corpus later.

### Revised method used here

1. Inventory all sources and classify them as primary, derived, or note-like.  
2. Extract atomic claims as candidate `P` or `E` items.  
3. Merge duplicates across sources into canonical principles, preserving source-specific caveats.  
4. Add agent-specific operational guidance as `A` only when it changes how the rule should be applied.  
5. Assign stable IDs to every canonical principle and every preserved example/fact.  
6. Group outputs by **operational domain**, not by source document.  
7. Produce a separate review of existing condensed files.  
8. Produce a separate traceability file mapping every extracted item to source location and output file.

## Why the output is split into these files

The corpus converges on six operational domains:

1. **Agent foundations**  
   Cold starts, finite context, explicitness, staleness, maps, and mechanical enforcement.

2. **Workflow, research, planning, and review**  
   Research/plan/implement, compaction, human leverage, mental alignment, task sizing, and risk.

3. **Harness, context control, and verification**  
   Harness engineering, MCP/tool surfaces, sub-agents, hooks, and back-pressure.

4. **Repository architecture and legibility**  
   Repo-as-system-of-record, AGENTS/ARCHITECTURE usage, observability, boundaries, entropy control, and autonomy loops.

5. **Skill design and distribution**  
   Skill packaging, categories, authoring rules, setup, memory, hooks, distribution, composition, and measurement.

6. **Prompt caching and prefix stability**  
   Prompt layout, mid-session stability, tool stability, cache-safe compaction, and monitoring.

This split is better than a single flat file because it matches how teams actually make design decisions:
- foundational assumptions,
- workflow/process,
- runtime/harness,
- repo structure,
- reusable capability modules,
- provider-specific performance constraints.

It also follows the corpus’s own advice: **maps beat manuals**, and **group by theme, not by source**.

## File index

- `principles/01_agent_foundations.md`
- `principles/02_workflow_research_planning_and_review.md`
- `principles/03_harness_context_and_verification.md`
- `principles/04_repository_architecture_and_legibility.md`
- `principles/05_skill_design_and_distribution.md`
- `principles/06_prompt_caching_and_prefix_stability.md`
- `reviews/existing_condensed_files_review.md`
- `principles_traceability.md`
