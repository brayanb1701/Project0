# Agents Foundations Extracted

This folder reorganizes the source corpus by **domain of use**, not by source document.

## Structure

- `methodology_assessment_and_structure.md`  
  Assessment of the original extraction prompt and the revised method used here.

- `principles/01_agent_foundations.md`  
  Cold starts, finite context, explicitness, staleness, maps, and enforcement.

- `principles/02_workflow_research_planning_and_review.md`  
  Research/plan/implement, compaction, human leverage, mental alignment, task sizing, and risk.

- `principles/03_harness_context_and_verification.md`  
  Harness engineering, tools/MCP, sub-agents, hooks, back-pressure, and context isolation.

- `principles/04_repository_architecture_and_legibility.md`  
  Repo-as-system-of-record, docs structure, observability, architectural invariants, throughput, autonomy, and entropy management.

- `principles/05_skill_design_and_distribution.md`  
  Skill packaging, categories, authoring rules, setup, state, scripts, hooks, distribution, composition, and measurement.

- `principles/06_prompt_caching_and_prefix_stability.md`  
  Prefix caching, prompt layout, mid-session stability, tool stability, cache-safe forking, and monitoring.

- `reviews/existing_condensed_files_review.md`  
  Evaluation of the already-condensed or already-derived files.

- `principles_traceability.md`  
  Mapping from each extracted principle/fact/example ID to its source location(s) and output file.

## Conventions

- `P` = principle
- `A` = agent-specific operational implication
- `E` = source-specific fact, metric, or implementation example
- Stable IDs are included so the corpus can be diffed, maintained, and audited later.
