# Harness, Context Control, and Verification
> Synthesized primarily from Harness_Eng_HumanLayer.md, Manage_Context_Window_DanielGriesser.md, ace-fca.md, AI-Engineer-Conference-EU-0426.md, and supporting overlaps across the corpus.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Harness Engineering

`[HC-01]` `P` **Harness engineering is how you get more out of today’s models.** For coding agents, many recurring failures are configuration failures, not pure model failures. The harness is the runtime surface—system prompt, tools, skills, context, sub-agents, hooks, and other control points—that shapes behavior.

`[HC-02]` `P` **Unexpected failure modes are structural, not temporary anomalies.** Smarter models will solve some current mistakes and then be trusted with larger, harder problems that produce new failure modes. Non-deterministic systems still need runtime design, not just optimism about the next release.

`[HC-03]` `P` **Treat harness engineering as a subset of context engineering.** The common job is to shape the information and capabilities the model sees so it can act coherently. Harness work is the runtime-facing subset: tool access, context isolation, determinism, progressive disclosure, and feedback loops.

`[HC-04]` `P` **Start simple; add harness complexity only after real failures.** Do not design the perfect harness in advance or install every extension “just in case.” Add configuration when it clearly prevents a real, repeated failure and helps you ship faster.

`[HC-04.A]` `A` **Operational implication.** A harness that is overbuilt before it is measured often burns context and attention without improving outcomes.

`[HC-05]` `P` **Post-training fit matters, but native harnesses are not always optimal.** Models can benefit from tools or interaction patterns they were post-trained on, but they can also be overfit to those defaults. Customization is justified when the default runtime is mismatched to the task or repo.

> `[HC-05.E1]` `E` OpenCode added an `apply_patch` tool to better match Codex expectations, yet the same article cites Terminal Bench data suggesting Opus 4.6 can rank much better in a non-native harness than in Claude Code.

---

## Tools, MCP, and Context Surfaces

`[HC-06]` `P` **Customize CLAUDE.md or AGENTS.md before touching more exotic levers.** The top-level agentfile is the deterministic front door into repo-specific behavior. It should be concise, human-written, and focused on universally applicable guidance plus pointers to deeper sources.

> `[HC-06.E1]` `E` HumanLayer’s cited CLAUDE.md is under 60 lines; OpenAI describes AGENTS.md at roughly 100 lines and treating it as a table of contents.

`[HC-07]` `P` **MCP servers are primarily for tools, and their descriptions are prompt material.** MCP extends capability, but the tool list, descriptions, and argument schema end up in the model’s prefix. That makes the server both a capability extension and an instruction surface.

`[HC-07.A]` `A` **Operational implication.** Anything injected through tools is also context; capacity and trustworthiness matter as much as nominal feature count.

`[HC-08]` `P` **Treat MCP connections and skill registries as security boundaries.** Untrusted tool descriptions can be prompt-injection vectors, and client-side servers or community skill registries can execute code on the host. Read what you install and connect only to servers you trust.

`[HC-09]` `P` **Too many tools are harmful even when individually useful.** Every irrelevant tool description consumes instruction budget and increases the odds that the model drifts into the dumb zone. Turn off large servers when idle, and progressively disclose big tool inventories instead of front-loading them.

`[HC-10]` `P` **Prefer thin CLIs or wrappers when only a small tool subset is actually needed.** If a server duplicates functionality already well represented in training data, or if you only use a narrow slice of it, a concise CLI can be more context-efficient and more composable with normal shell tools.

> `[HC-10.E1]` `E` HumanLayer replaced the verbose Linear MCP usage with a small Linear CLI plus six example commands in CLAUDE.md, saving both system-prompt tokens and verbose response tokens.

---

## Sub-Agents and Context Isolation

`[HC-11]` `P` **Sub-agents are for context control, not roleplay.** The useful abstraction is not “frontend engineer” or “backend engineer,” but isolated sessions that do discrete noisy work and return only the compressed result. Their main value is acting as a context firewall around intermediate search, read, and reasoning noise.

`[HC-12]` `P` **Long context is not a substitute for isolation.** Bigger windows often enlarge the haystack without making the model better at finding the needle. Better context window isolation is usually higher leverage than simply buying more sequence length.

`[HC-12.A]` `A` **Operational implication.** Use long context as slack, not as the primary design strategy for complex agentic work.

`[HC-13]` `P` **Use sub-agents for search-heavy tasks that have simple deliverables.** Definition lookup, pattern discovery, request tracing, documentation research, and similar tasks often require many tool calls but return a compact answer. The parent session should only absorb that answer plus enough citations to re-open the evidence on demand.

`[HC-14]` `P` **Cheap models often suffice for isolated sub-agent tasks.** Keep the expensive model on orchestration, planning, and synthesis, and use cheaper/faster models for bounded retrieval or grep-like work. Context isolation creates smaller tasks with smaller instruction budgets.

`[HC-15]` `P` **If the harness lacks native sub-agents, you can emulate them—but define scope tightly.** A launcher tool or MCP server can start fresh agent sessions and return their final response, but you must constrain what the sub-agent should do, what it should not do, how it should report, and what tools it may use.

`[HC-15.A]` `A` **Operational implication.** Poorly scoped nested agents produce “telephone” effects and timeout problems rather than useful isolation.

`[HC-16]` `P` **Offload noisy investigation into persistent artifacts.** A separate agent or tool should be able to browse, test, and verify in its own context, then write the distilled result to a durable file. Persistence matters because it turns ephemeral exploration into reusable knowledge.

> `[HC-16.E1]` `E` Daniel Griesser’s Pi harness added a custom `claude` tool that spawns a separate Claude Code session, lets it search, run commands, and verify behavior, then writes only the verified findings to markdown.

> `[HC-16.E2]` `E` In Pi’s workflow, the agent learned to invoke the custom `claude` tool autonomously to verify reviewer findings against docs and source code, without an explicit human prompt.

> `[HC-16.E3]` `E` The same article credits session forking—about eight forks during tool development—with revealing that writing distilled findings to file was necessary.

---

## Hooks, Back-Pressure, and Verification

`[HC-17]` `P` **Hooks are for deterministic control flow, integration, and silent automation.** Hooks can auto-run commands on lifecycle events, augment tool calls, gate dangerous actions, or silently verify work. They are structural control surfaces, not just convenience scripts.

`[HC-18]` `P` **Good hooks are silent on success and loud only on actionable failure.** Passing builds, typechecks, or formatters should not flood the context window. Failures should re-engage the agent with just enough error detail to fix the issue.

> `[HC-18.E1]` `E` HumanLayer’s example hook runs formatting and typechecking at stop time, surfaces only errors, and uses exit code 2 to force the harness to hand control back to the agent.

`[HC-19]` `P` **Back-pressure is one of the highest-leverage reliability investments.** The more directly the agent can verify its own work, the higher the chance of success. Tight feedback loops via typechecks, tests, coverage, and UI verification are multiplicative, not optional polish.

`[HC-19.A]` `A` **Operational implication.** Closed-loop tasks are disproportionately valuable because they let the agent correct itself before the human has to intervene.

`[HC-20]` `P` **Verification must itself be context-efficient.** Flooding the session with thousands of passing test lines or full successful build logs degrades the next decision. Swallow success, surface only failures, and prefer the smallest validation set that still gives meaningful signal.

`[HC-21]` `P` **Mechanical guardrails should encode common local failures before they scale.** If agents tend to swallow errors, query the database incorrectly, bypass component libraries, or duplicate names, turn those failure modes into hard checks rather than recurring review comments.

> `[HC-21.E1]` `E` Conference notes propose concrete checks such as forbidding bare catch-alls, raw SQL outside the abstraction layer, raw input boxes outside the component library, dynamic imports, and non-unique function names.

---

## Anti-Patterns

- Blaming the model before checking the harness, context surface, or verification loop.
- Installing large tool inventories or many skills “just in case.”
- Using anthropomorphic sub-agent roles instead of context-isolation tasks.
- Relying on ever-larger context windows instead of structural isolation.
- Surfacing passing logs and test output to the model on every step.
- Connecting untrusted MCP servers or skill bundles without inspection.
