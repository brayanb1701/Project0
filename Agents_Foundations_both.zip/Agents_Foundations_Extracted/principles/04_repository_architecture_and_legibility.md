# Repository Architecture and Agent Legibility
> Synthesized primarily from Harness_Engineering(2).md, Agent_Project_Principles(2).md, Architecture_Doc_Principles(2).md, AI-Engineer-Conference-EU-0426.md, and supporting overlaps across the corpus.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Knowledge Architecture

`[RA-01]` `P` **Treat the repository as the system of record.** For agents, durable knowledge should live in versioned repo artifacts: architecture docs, design docs, product specs, execution plans, generated schemas, quality docs, and reference material. Anything outside that boundary is best-effort memory, not dependable context.

`[RA-02]` `P` **Top-level agent docs should be tables of contents, not encyclopedias.** AGENTS.md or CLAUDE.md should orient and point onward, not try to carry the whole knowledge base. Their job is to preserve a stable entry point that enables progressive disclosure.

`[RA-03]` `P` **Plans are first-class artifacts, not disposable prompts.** Execution plans, decision logs, active work records, completed plans, and debt trackers should be checked into the repo. Long-horizon tasks need durable artifacts that survive session boundaries.

`[RA-04]` `P` **Validate documentation freshness mechanically.** Use linters, CI, and recurring doc-maintenance agents to keep the knowledge base cross-linked, structured, and up to date. Do not trust passive human memory to keep repo knowledge synchronized with code.

> `[RA-04.E1]` `E` OpenAI describes dedicated doc linters plus a recurring “doc-gardening” agent that scans for obsolete documentation and opens fix-up PRs.

---

## Application Legibility

`[RA-05]` `P` **Optimize the codebase for agent legibility.** The repository should be easy for future agent runs to inspect, reason about, and modify. Human aesthetic preference matters less than correctness, maintainability, and machine-navigable structure.

`[RA-05.A]` `A` **Operational implication.** Your codebase is infrastructure for the agent; design it as a runtime environment, not only as a human code archive.

`[RA-06]` `P` **Make the running system observable to agents, not just the source tree.** Agents need to reproduce failures, validate fixes, and reason about behavior. Wire the app, browser/UI, logs, metrics, and traces into the runtime so the agent can inspect the actual system it is changing.

> `[RA-06.E1]` `E` OpenAI’s setup makes the app bootable per git worktree and exposes Chrome DevTools, DOM snapshots, screenshots, navigation, and an ephemeral observability stack queryable via LogQL, PromQL, and TraceQL.

`[RA-07]` `P` **Isolate each task’s environment.** A change should run against its own instance of the application and its own observability context. Isolation limits cross-task contamination and makes validation results attributable to the current work.

`[RA-08]` `P` **Prefer boring, inspectable, composable technology.** Stable APIs and well-represented tools are easier for agents to model. A small internal implementation the agent can inspect and change is sometimes superior to a black-box dependency with opaque behavior.

> `[RA-08.E1]` `E` OpenAI chose to implement an internal map-with-concurrency helper rather than rely on `p-limit`, because the custom helper was inspectable, tightly integrated with telemetry, and fully tested.

---

## Architecture and Invariants

`[RA-09]` `P` **Enforce invariants, not implementations.** Define strict structural boundaries and allowed dependency directions, then allow freedom inside them. The point is not stylistic uniformity; it is preventing architectural drift while keeping local solution space open.

`[RA-10]` `P` **Architectural rigor is an early prerequisite in agent-built systems.** With high agent throughput, weak structure decays quickly. Constraints that human teams might postpone until later become necessary much earlier so speed does not produce incoherence.

`[RA-11]` `P` **Make layer boundaries and injection points unambiguous.** The agent should know exactly what can depend on what, where cross-cutting concerns enter, and what layer new code belongs to. Ambiguous boundaries produce local fixes that break global coherence.

> `[RA-11.E1]` `E` OpenAI’s example layer model is Types → Config → Repo → Service → Runtime → UI, with auth, telemetry, connectors, and feature flags entering through an explicit Providers interface.

`[RA-12]` `P` **Encode human taste as checks, not repeated commentary.** If a review comment recurs, promote it into a linter, structural test, or template. Once encoded, the preference applies continuously instead of being rediscovered on every PR.

`[RA-13]` `P` **Design away hidden magic and local over-protection.** Agents naturally optimize for code that appears to run, which can lead to broad exception swallowing, silent defaults, and patch-local fixes that hide real failures. Good design makes important behavior visible and lets failures propagate to the right level.

> `[RA-13.E1]` `E` Conference notes argue that a service silently running with the wrong configuration is worse than a service that refuses to start, because local over-protection hides global failures.

`[RA-14]` `P` **Understand where agents excel and where they struggle.** Agents perform best on clearly defined problems with compact surfaces, tight constraints, and a stable core. They struggle on interacting concerns, diffuse ownership, and situations where the full picture does not fit cleanly into context.

---

## Throughput, Autonomy, and Entropy

`[RA-15]` `P` **High throughput changes merge philosophy, but not the need for a quality floor.** When corrections are cheap and waiting is expensive, short-lived PRs and minimal blocking gates can be rational—but only when strong mechanical validation already exists and working code remains the floor, not an optional aspiration.

`[RA-16]` `P` **Risk should determine review rigor.** Low-risk, highly mechanical changes can move quickly under automation. Architecture, security, and other cross-cutting changes deserve heavier review and stronger consensus before they merge.

`[RA-17]` `P` **Autonomy emerges from encoded feedback loops.** End-to-end autonomous execution becomes plausible only after testing, validation, observability, review, and recovery have all been encoded into the repository and harness. Autonomy is the result of scaffolding, not a switch you flip.

> `[RA-17.E1]` `E` OpenAI describes a mature loop where a single prompt can validate the codebase, reproduce a bug, record failure and resolution videos, implement and verify the fix, open a PR, address feedback, remediate build failures, escalate only for judgment, and merge.

`[RA-18]` `P` **Measure throughput as evidence, not as the goal.** Case-study numbers are useful because they show that the workflow is real, but throughput only matters when it sits on top of architecture, validation, and maintainability.

> `[RA-18.E1]` `E` OpenAI reports roughly 1 million lines of agent-written code in about five months, around 1,500 PRs, and about 3.5 PRs per engineer per day, with throughput increasing as the team grew.

> `[RA-18.E2]` `E` ace-fca reports an hour-scale bug fix in a 300k LOC Rust codebase and a roughly 35k LOC feature push in one day, but frames those outcomes as products of workflow and review, not of unconstrained speed.

`[RA-19]` `P` **Entropy management is continuous garbage collection.** Agents will amplify whatever already exists, good or bad. Background cleanup, targeted refactors, and pre-submission normalization are necessary to keep the codebase legible as the volume of generated code rises.

---

## Anti-Patterns

- Treating the repo as code-only while leaving the real architecture in external conversations.
- Optimizing for human style preferences while ignoring machine navigability and inspectability.
- Depending on opaque libraries when a small inspectable internal abstraction would be easier to reason about.
- Leaving boundaries and injection points implicit.
- Merging fast without strong mechanical validation.
- Letting entropy accumulate and planning to fix it later in one large cleanup pass.
