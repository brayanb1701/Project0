# Skill Design and Distribution
> Synthesized primarily from Skills_Use_Anthropic_engineer.md and Skills_Use_Anthropic_engineer.condensed(2).md, with supporting overlaps from Harness_Eng_HumanLayer.md and Manage_Context_Window_DanielGriesser.md.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Skill Model and Categories

`[SK-01]` `P` **Skills are packaged capabilities, not just markdown prompts.** A skill can bundle instructions, scripts, assets, templates, examples, data, config, and hooks inside a discoverable folder. The model’s leverage comes from the whole package, not only the prose file.

`[SK-02]` `P` **Useful skill inventories cluster into recurring categories.** A strong skill usually has one clear dominant job. Confusing skills tend to straddle several jobs and become harder to trigger, maintain, and evaluate.

> `[SK-02.E1]` `E` The corpus identifies nine recurring categories: library/API reference, product verification, data fetching and analysis, business process automation, code scaffolding/templates, code quality/review, CI/CD and deployment, runbooks, and infrastructure operations.

`[SK-03]` `P` **Verification skills deserve disproportionate investment.** If a skill helps the agent prove that its work is correct, it amplifies every downstream coding task. Excellent verification skills are worth dedicated engineering time.

> `[SK-03.E1]` `E` Anthropic suggests techniques such as recording videos of the agent’s test run and enforcing programmatic assertions on state at each step.

---

## Authoring High-Signal Skills

`[SK-04]` `P` **Do not waste skill tokens stating the obvious.** Focus skills on non-obvious local knowledge, footguns, preferences, and operational deltas that the base model would not reliably infer. Generic coding advice dilutes trigger quality and burns context budget.

`[SK-05]` `P` **The gotchas section is the highest-signal part of many skills.** Build gotchas from repeated model failure points and keep updating them over time. They are the shortest path from past failure to future prevention.

`[SK-06]` `P` **Use the file system for progressive disclosure inside the skill.** Split detailed signatures, usage examples, templates, scripts, references, and assets into separate files or folders so the agent can pull them in only when needed.

`[SK-07]` `P` **Avoid railroading.** Skills must be reusable across contexts, so they should guide rather than overconstrain. Too-specific instructions make the skill brittle and reduce its usefulness outside the author’s exact scenario.

`[SK-08]` `P` **Design setup explicitly when user- or org-specific context is required.** If a skill depends on local configuration, store it in a config file and ask the user only when the value is missing. Structure the question format when the answer space is constrained.

`[SK-08.A]` `A` **Operational implication.** Explicit setup removes repeated clarification churn and keeps the main skill focused on execution rather than rediscovery.

`[SK-09]` `P` **The description field is for model triggering, not human summary.** Skill discovery depends on whether the model recognizes that a matching skill exists for the current request. The description should therefore describe when to invoke the skill, not merely what it is in human-facing terms.

---

## State, Scripts, and Hooks

`[SK-10]` `P` **Skills can carry memory and state, but storage location matters.** Append-only logs, JSON, or SQLite can help the agent stay consistent across repeated runs. Stable long-lived state should live in a durable plugin data path rather than inside an upgrade-prone skill folder.

> `[SK-10.E1]` `E` Anthropic’s example is a standup-post skill that keeps a log of past posts so the next run can compute deltas rather than re-summarize everything from scratch.

`[SK-11]` `P` **One of the strongest skill assets is code.** Bundled scripts and helper libraries let the agent compose existing capability instead of repeatedly regenerating boilerplate. That shifts model effort from reconstruction to orchestration and higher-level reasoning.

`[SK-12]` `P` **On-demand hooks turn skills into temporary guardrail bundles.** Some guardrails are invaluable only in specific sessions. Activating hooks only when the skill is invoked lets you enforce temporary operational constraints without carrying them globally all the time.

> `[SK-12.E1]` `E` Examples include `/careful` to block destructive commands in sensitive sessions and `/freeze` to block edits outside an allowed directory.

---

## Distribution, Composition, and Safety

`[SK-13]` `P` **Repo-local skills and marketplace skills solve different scaling problems.** Checking skills into the repo is simple for smaller teams and few repos, but every checked-in skill adds some ambient context overhead. As the organization scales, installable plugins or marketplaces let teams pull in only what they need.

`[SK-14]` `P` **Let skills emerge organically, then curate them.** Useful skills are easier to identify by real adoption than by central planning. Lightweight experimentation should precede wider release, but broad distribution still needs curation because bad or redundant skills are easy to create.

`[SK-15]` `P` **Skills can compose even without first-class dependency management.** A skill can reference other skills by name and rely on the model to invoke them if installed. Composition is therefore possible, but it depends on naming clarity and discoverability.

`[SK-16]` `P` **Measure skill usage and undertriggering.** Instrumentation helps you learn which skills are valuable, which are rarely used, and which are probably described poorly enough that the model misses them. Skill design is easier to improve when trigger behavior is observable.

`[SK-17]` `P` **Treat shared skills like executable dependencies.** Community registries and plugin bundles can contain malicious or unsafe code. Reading a skill before installation should be as normal as auditing an unfamiliar package before adding it to production tooling.

---

## Anti-Patterns

- Treating a skill as only a long prompt instead of as a packaged capability.
- Writing generic advice the model already knows.
- Skipping a gotchas section built from real failures.
- Over-specifying a reusable skill until it becomes brittle.
- Writing human-friendly descriptions that fail to trigger the model.
- Storing long-lived state in upgrade-prone skill directories.
- Publishing many low-value or redundant skills without curation.
- Installing third-party skill bundles without inspecting what they execute.
