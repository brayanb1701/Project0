# Agent Foundations
> Synthesized from Agent_Oriented_Thinking(2).md, Architecture_Doc_Principles(2).md, knowledge_extraction_prompt.md, Harness_Engineering(2).md, Agent_Project_Principles(2).md, and supporting overlaps across the corpus.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Context and Memory

`[AF-01]` `P` **Agents start cold every run.** Assume no accumulated intuition, no remembered conventions, and no persistent mental map. Every artifact that matters must re-orient a fresh agent inside the available context window.

`[AF-01.A]` `A` **Operational implication.** Cold-start makes missing orientation more dangerous for agents than for humans; navigation hints are operational requirements, not nice-to-haves.

`[AF-02]` `P` **Context is finite and scarce.** Tokens spent on background, repetition, or irrelevant detail compete directly with the task. Maps beat manuals; pointers beat copies; progressive disclosure beats exhaustive upfront loading.

`[AF-02.A]` `A` **Operational implication.** Design every durable artifact to answer the next navigation question and point onward, not to restate the entire system.

`[AF-03]` `P` **If it is not repo-local and discoverable, it does not exist for the agent.** Slack threads, Google Docs, verbal agreements, and tacit team memory are invisible unless reified as repository-local artifacts or explicitly bundled skill assets.

`[AF-03.A]` `A` **Operational implication.** Treat external discussions as raw material; convert load-bearing decisions into versioned markdown, schemas, plans, or skill references before expecting the agent to honor them.

`[AF-04]` `P` **Staleness is a silent corruption vector.** Humans notice contradictions between docs and code; agents usually do not. A stale document silently becomes a false model that the agent will execute against.

`[AF-04.A]` `A` **Operational implication.** Any document an agent depends on should be checked and updated as part of the task that touches it, not via occasional human cleanups.

---

## Explicitness and Placement

`[AF-05]` `P` **Explicit beats implicit.** State conventions, dependency directions, naming rules, placement logic, and rationale directly. Agents cannot absorb team norms through long exposure the way humans do.

`[AF-05.A]` `A` **Operational implication.** Whenever a rule would otherwise be inferred socially or historically, write it down near the entry point that the agent will actually read.

`[AF-06]` `P` **Always answer “where does new X go?”.** New files, modules, handlers, and types need explicit placement rules. Without them, agents extrapolate from the nearest visible example, including outdated exceptions.

`[AF-06.A]` `A` **Operational implication.** Placement rules should name the file, layer, or directory pattern, not just the conceptual concern.

`[AF-07]` `P` **Name the injection point and the rationale.** Saying that a concern exists is weaker than naming the exact place it enters the system and why the boundary exists. Unexplained constraints look removable to an optimizing agent.

`[AF-07.A]` `A` **Operational implication.** For cross-cutting concerns, say both where to hook in and what architectural failure the rule prevents.

---

## Documentation as Maps

`[AF-08]` `P` **Architecture and agent docs should be maps, not atlases.** High-value documents explain the problem being solved, the coarse-grained structure, the major boundaries, and where to look next. They should not try to inline every implementation detail.

`[AF-08.A]` `A` **Operational implication.** Maps stay readable and durable inside constrained contexts; encyclopedic docs crowd out the task and rot faster.

`[AF-09]` `P` **Only encode stable, low-maintenance orientation in top-level docs.** Top-level maps should name important modules, invariants, boundaries, and cross-cutting concerns, but avoid volatile detail and direct links that are likely to go stale.

`[AF-09.A]` `A` **Operational implication.** Shorter documents are not just nicer—they are more likely to remain true, be read, and fit into context when needed.

`[AF-09.E1]` `E` Source-local evidence for concise maps. The ETH Zurich study summary in the corpus reported that LLM-generated agentfiles hurt performance, human-written ones helped only slightly, and directory listings or broad overviews did not materially help because agents can discover structure themselves.

---

## Enforcement and Drift

`[AF-10]` `P` **Mechanical enforcement beats documented rules.** A principle that exists only in prose will eventually be violated. Lints, structural tests, CI checks, and enforced boundaries turn norms into continuously applied behavior.

`[AF-10.A]` `A` **Operational implication.** When possible, pair every important invariant with the exact tool that enforces it so the agent can both comply and verify.

`[AF-11]` `P` **Error messages are agent instructions.** Diagnostics should say not only what failed but how to remediate it. The next useful prompt for the agent should already be encoded in the linter, test failure, or CI message.

`[AF-11.A]` `A` **Operational implication.** Custom lint messages are one of the highest-leverage places to inject repo-specific repair behavior.

`[AF-12]` `P` **Agents replicate existing patterns, including bad ones.** Whatever is common in the codebase becomes the template. Inconsistent or degraded patterns therefore compound unless the preferred pattern is encoded once and enforced everywhere.

`[AF-12.A]` `A` **Operational implication.** Fixing one PR by comment is weaker than promoting the preference into a linter, template, or recurring cleanup task.

`[AF-13]` `P` **Pay down drift continuously.** Background scans and small correction PRs beat occasional “cleanup Fridays” or large refactors. Technical debt behaves like compounding interest in agent-generated systems.

> `[AF-13.E1]` `E` OpenAI’s team initially spent about 20% of its week manually cleaning AI-generated slop, then replaced that with recurring background scans, quality grading, and small refactoring PRs.

---

## Anti-Patterns

- Monolithic manuals that try to encode the whole system in one file.
- Knowledge that lives only in chat, tickets, or people’s heads.
- Implicit placement rules, invisible boundaries, or unexplained constraints.
- Direct links and volatile detail in orientation docs.
- Policies stated in prose without matching enforcement.
- Periodic manual cleanup instead of continuous drift control.
