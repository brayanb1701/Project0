# Workflow, Research, Planning, and Review
> Synthesized primarily from ace-fca.md, Dex Process on coding with agents.md, Manage_Context_Window_DanielGriesser.md, AI-Engineer-Conference-EU-0426.md, and supporting overlaps across the corpus.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Role of the Human

`[WF-01]` `P` **Humans steer; agents execute.** The highest-leverage human work shifts upward: specify intent, design the environment, choose the task decomposition, and decide where judgment is still required. Direct code writing is no longer the only or primary leverage point.

`[WF-01.A]` `A` **Operational implication.** When the loop works, the human’s comparative advantage is not typing code but selecting goals, checking abstractions, and intervening at leverage points.

`[WF-02]` `P` **When work fails, debug the system before blaming effort.** Default first question: what capability, context, structure, or verification loop is missing? Retry-only thinking hides the real bottleneck.

`[WF-02.A]` `A` **Operational implication.** Model escalation is still valid, but only after root-cause analysis shows that the failure is not primarily a context, tooling, or harness problem.

`[WF-03]` `P` **Do not outsource the thinking.** Planning, design judgment, and framing remain high-leverage human tasks. A stronger prompt is not a substitute for deciding what should be built and why.

`[WF-03.A]` `A` **Operational implication.** Let the agent execute and accelerate, but keep humans responsible for framing, acceptance, and final judgment.

---

## Context Compaction

`[WF-04]` `P` **Naive long-lived chat sessions are the baseline failure mode.** Pure back-and-forth “vibe coding” accumulates noise until the agent runs out of context, gets off track, or starts apologizing. Starting over with only slight prompt tweaks is only marginally better.

`[WF-05]` `P` **Intentional compaction should happen before the context is unusable.** Pause work and distill progress into a structured artifact that preserves the goal, approach, completed steps, and current failure state. The point is to carry forward only the signal.

> `[WF-05.E1]` `E` ace-fca suggests progress files or even commit messages as compaction artifacts; Pi writes distilled findings to markdown so knowledge persists outside the ephemeral window.

`[WF-06]` `P` **Compaction exists to remove specific classes of noise.** The main context eaters are file search, flow discovery, edits, build/test logs, and verbose tool outputs like giant JSON blobs. Compaction should replace them with a compact, structured state summary.

`[WF-07]` `P` **Optimize context for correctness, completeness, size, and trajectory.** Incorrect information is worse than missing information, and missing information is worse than extra noise. Good workflows therefore protect both factual accuracy and forward motion, not just raw token count.

`[WF-08]` `P` **Frequent intentional compaction works better than episodic rescue.** Design the whole workflow around context management and keep active utilization modest enough to leave room for course correction, summaries, and verification.

> `[WF-08.E1]` `E` ace-fca recommends operating around roughly 40–60% context utilization, depending on task complexity.

> `[WF-08.E2]` `E` Pi’s Sentry-skill workflow produced 7 commits and 4,158 lines across 15 files while using about half of a 200k context window and about 34k tokens of output.

---

## Research and Planning

`[WF-09]` `P` **Use an explicit research → plan → implement flow for complex work.** Research establishes the factual map, planning defines exact changes and verification, and implementation executes phase by phase. The phases can be skipped or repeated, but keeping them distinct increases legibility and control.

`[WF-09.A]` `A` **Operational implication.** Separate phases make it easier to review the highest-leverage artifact at each stage and to compact progress back into durable markdown.

> `[WF-09.E1]` `E` ace-fca notes that research may be skipped or repeated, but recommends separating the steps; it also notes that, in that workflow, only the implementation phase needed a git worktree.

`[WF-10]` `P` **Research should compress truth, not smuggle in implementation bias.** Discourage opinions and premature implementation plans; first decide the right questions, then gather evidence. Hiding the ticket or feature description from the researcher can preserve objectivity.

`[WF-11]` `P` **Planning should be modular, vertical, and control-flow-aware.** Break planning into design, structural outline, and final implementation plan. Use real control flow for state transitions and keep the final plan vertically executable rather than a broad horizontal wish list.

> `[WF-11.E1]` `E` Dex recommends keeping intermediate markdown files around ~200 lines, with refinement happening before the final detailed plan is produced.

`[WF-12]` `P` **Compact verified implementation status back into the plan.** For long or phased work, the plan should evolve into the current state document. Once a phase is verified, update the plan so the next session resumes from truth rather than from stale chat history.

`[WF-13]` `P` **Research quality has a larger blast radius than code quality.** A bad line of research can produce thousands of bad lines of code, and a bad line of plan can produce hundreds. Review attention should concentrate at the highest leverage stage, not only at the final diff.

> `[WF-13.E1]` `E` In BAML, a research-backed plan fixed the issue in the best place and matched codebase testing conventions; a no-research plan also “would have worked,” but less well.

> `[WF-13.E2]` `E` The parquet-java attempt failed because the research step did not go deep enough through the dependency tree and neither human was a domain expert.

---

## Review, Risk, and Task Selection

`[WF-14]` `P` **Code review for agent-built systems must preserve mental alignment.** The challenge is not only correctness but keeping the team oriented as code volume rises. Specs, plans, research docs, and other compact artifacts can preserve shared understanding better than giant diffs alone.

> `[WF-14.E1]` `E` ace-fca contrasts unsustainable 2,000-line Go PR review with manageable review of a roughly 200-line implementation plan.

`[WF-15]` `P` **Good agent tasks are scoped, closed-loop, and easy to evaluate.** Choose work the agent can verify, where the blast radius is bounded and the success criteria are concrete. Reproduction cases, debugging tools, boring experiments, and first drafts are especially suitable.

`[WF-16]` `P` **Use smaller PRs and cap generated code to review capacity.** As task size grows, reviewability drops faster than code volume. Critical code deserves line-level scrutiny; non-critical or exploratory work can move with lighter review and stronger automation.

> `[WF-16.E1]` `E` Conference notes warn that once generated code and even huge test suites become too large to trust holistically, review depth should scale with criticality: non-critical code can move faster, but critical code should be reviewed line by line.

`[WF-17]` `P` **Precision beats vibes when you need engineering, not wishful execution.** There is a meaningful difference between precisely steering targeted changes and merely describing a desired outcome and hoping the system converges. The latter is fine for exploration, but weaker for exact work.

`[WF-18]` `P` **There is no magic prompt.** Hard problems still require engaged steering, iteration, and sometimes codebase expertise. Better workflow improves odds, but it does not eliminate the need for judgment.

---

## Anti-Patterns

- Treating a long chat transcript as the durable system of record.
- Letting research drift into solutioning before the questions are clear.
- Using prompts to fake control flow that should exist structurally in the workflow.
- Reviewing only code while skipping the research and plan that generated it.
- Assigning giant, ambiguous, mission-critical work with weak verification.
- Expecting one magic prompt to replace engagement, iteration, and expertise.
