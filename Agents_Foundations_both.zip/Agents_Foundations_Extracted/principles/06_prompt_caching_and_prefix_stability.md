# Prompt Caching and Prefix Stability
> Synthesized primarily from Prompt Caching is Everything.md and Prompt Caching is Everything.condensed(2).md, with supporting overlaps from Harness_Eng_HumanLayer.md.

**Legend:** `P` = Core Principle · `E` = Implementation Example or Fact · `A` = Agent-specific consideration

---

## Prefix Matching Fundamentals

`[PC-01]` `P` **Prompt caching is prefix-based.** Cached computation is reused only when the beginning of the request matches. Any change anywhere in the cached prefix invalidates everything after it.

`[PC-02]` `P` **Long-running agent products should treat cache hit rate like production health.** Cache misses are not minor bookkeeping errors; they directly affect cost, latency, and rate limits. Monitor hit rate and investigate regressions aggressively.

`[PC-03]` `P` **Lay prompts out as static first, dynamic last.** The highest-shared, least-changing material should appear earliest in the prefix, followed by progressively more local and volatile context.

> `[PC-03.E1]` `E` Claude Code’s cited ordering is: static system prompt and tools, then project context (CLAUDE.md), then session context, then conversation messages.

`[PC-04]` `P` **Prefix stability is fragile and must be made deterministic.** Seemingly minor variation can silently wipe out cache reuse. Timestamps, shuffled tool order, and dynamic tool parameter changes are enough to break the shared prefix.

`[PC-04.A]` `A` **Operational implication.** Deterministic serialization of tools, context blocks, and instruction surfaces is part of harness design, not just of request formatting.

---

## Mid-Session Stability

`[PC-05]` `P` **Use messages for dynamic updates instead of editing the system prompt.** When time, file state, or other volatile information changes, inject it in the next message or tool result rather than rewriting the prompt prefix and paying a cache miss.

> `[PC-05.E1]` `E` Claude Code adds `<system-reminder>` tags in subsequent user or tool messages so the cache-bearing prefix stays intact.

`[PC-06]` `P` **Do not switch models mid-session if you care about cache efficiency.** Prompt caches are model-specific. A cheaper model can be more expensive overall if switching to it requires rebuilding a large cached conversation from scratch.

`[PC-06.A]` `A` **Operational implication.** If you need a second model, hand off a bounded task to a sub-agent and preserve the parent session’s cache.

---

## Tool and Mode Design

`[PC-07]` `P` **Do not add or remove tools mid-session.** Tools are part of the cached prefix. Dynamic tool-set changes invalidate the conversation cache, even if the change feels intuitively small.

`[PC-08]` `P` **Model state transitions as tools, not as tool-set swaps.** If the mode changes, represent the mode change explicitly while keeping the overall tool inventory stable. That preserves the prefix and can even let the model enter the mode autonomously when appropriate.

> `[PC-08.E1]` `E` Claude Code’s plan mode keeps the full tool set present and uses EnterPlanMode and ExitPlanMode as tools, plus mode instructions, instead of swapping in read-only tools.

`[PC-09]` `P` **Defer loading rather than removing tools.** Large tool inventories should be represented by lightweight, stable stubs in a stable order, with full schemas loaded only on demand. Progressive disclosure can preserve both cache stability and token efficiency.

---

## Forking and Monitoring

`[PC-10]` `P` **Forked computations should share the parent’s prefix whenever possible.** Compaction, summarization, or other side computations can become unexpectedly expensive if they use a different system prompt or tool set. Reusing the parent’s full prefix preserves the cache on the shared history.

`[PC-11]` `P` **Cache-safe compaction appends the compaction request to the parent conversation.** Send the same system prompt, tools, and history as the parent session, then append the compaction instruction as a new user message. That keeps almost the whole request cacheable.

> `[PC-11.E1]` `E` The corpus notes that naive compaction with a different system prompt and no tools gets zero cache reuse on the parent history.

`[PC-12]` `P` **Reserve buffer space for compaction.** If compaction is part of the runtime, the session must leave room for both the compaction instruction and the resulting summary. Otherwise the system runs out of space at the exact moment it needs to summarize.

`[PC-13]` `P` **Use provider-native compaction features when they encode these lessons already.** If the API already exposes a compaction primitive that preserves caching correctly, prefer it over a bespoke implementation. Recreating the mechanism naively is a common source of invisible cost inflation.

`[PC-13.A]` `A` **Operational implication.** This file is intentionally provider-scoped; other providers may use different cache semantics, so port the principle, not the literal API shape.

---

## Anti-Patterns

- Putting volatile data early in the cached prefix.
- Editing the system prompt for routine state changes.
- Switching models mid-conversation to chase lower per-token prices.
- Adding and removing tools as modes change.
- Launching compaction or summarization with a different prefix than the parent conversation.
- Ignoring cache-hit monitoring until cost or latency regressions become obvious.
